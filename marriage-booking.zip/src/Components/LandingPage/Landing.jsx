import React from 'react';
import './Landing.css';

import Slider from '../Slider/Slider';
import { Header } from '../Header/Header';


const LandingPage = () => {
  return (
    <>
<Header/>
     <Slider/>

  
    </>
   
  
    
    
    
  );
};

export default LandingPage;
